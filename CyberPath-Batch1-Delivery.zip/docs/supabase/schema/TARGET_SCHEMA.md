# مخطط قاعدة البيانات المستهدف — CyberPath

**مبدأ:** هوية ≠ دخول ≠ تسجيل أكاديمي ≠ استحقاق ≠ تقدم مقرر ≠ تقدم مختبر.

## 1) كيانات موجودة (Production — لا تُحذف)

| جدول | الوظيفة | ملاحظات حماية |
|------|---------|----------------|
| `auth.users` | هوية Auth | لا يُلمَس من migrations العامة |
| `public.user_profile` | ملف متعلم مرتبط بـ `user_id` | **مُصلَح حيًا**؛ لا SELECT لـ role/national_id/student_number للعميل |
| `public.courses` | مقررات | قراءة عامة؛ كتابة service/admin فقط |
| `public.lessons` | دروس ضمن مقرر | `lesson_id` → `course_id`؛ قراءة عامة |
| `public.enrollments` | تسجيل مستخدم في مقرر | ليس متابعة مفتوحة؛ عزل صفوف |
| `public.learning_progress` | تقدم درس | لا إثبات شهادة من العميل؛ INTEGER percentage |

## 2) كيانات مستهدفة (دفعات لاحقة — تصميم فقط الآن)

| جدول مقترح | الغرض | الدفعة المقترحة |
|------------|--------|-----------------|
| `identity_proofs` | إثباتات تحقق أكاديمي/مؤسسي (رمز، حالة، مُراجِع) | B3+ |
| `entitlements` | صلاحيات مشتقة من اشتراك/مؤسسة — **ليس** عمود role | تجاري لاحق |
| `subscriptions` | اشتراكات | خارج Phase 3 الحالي |
| `quiz_attempts` / إجابات منفصلة عن `quiz_answers` الحالي إن بقي غير آمن | محاولات تقييم موثوقة | B4 |
| `lab_attempt_local_meta` | اختياري لاحقًا لمزامنة مختبر — **ليس** إلزام Phase 3 | مؤجل |
| `audit_events` | سجل أحداث أمنية (تغيير دور، ربط، trust progress) | B3 |
| `course_publish_state` أو عمود `is_published` على courses | إن ثبت وجود محتوى غير عام | بعد دليل مخطط |

## 3) علاقات (كاردينالية)

```
auth.users 1 ── 0..1 user_profile
user_profile 1 ── * enrollments * ── 1 courses
courses 1 ── * lessons
user_profile 1 ── * learning_progress * ── 1 lessons
learning_progress.course_id يجب أن يطابق lessons.course_id (قيد منطقي / RPC)
```

## 4) مصدر الحقيقة

| معلومة | المصدر |
|--------|--------|
| هل المستخدم مسجّل دخول | Supabase Auth session |
| الدور التشغيلي (student/admin/…) | `get_my_role()` فقط — ليس JWT metadata وليس SELECT role |
| تقدم درس ذاتي | `report_lesson_activity` → learning_progress |
| تقدم موثوق/إكمال | `trust_set_lesson_progress` عبر service_role فقط |
| تقدم مختبر | تخزين محلي للمتصفح (Phase 3) |
| تسجيل أكاديمي | عملية تحقق خادم — ليست تطابق بريد |

## 5) صلاحيات ملخصة

| السطح | anon | authenticated | service_role |
|-------|------|---------------|--------------|
| courses/lessons SELECT | نعم | نعم | نعم |
| courses/lessons كتابة | لا | لا | نعم |
| enrollments/progress SELECT | لا | صفوفه فقط | نعم |
| enrollments/progress كتابة مباشرة | لا | لا | نعم / RPC |
| user_profile | كما أُصلح حيًا | كما أُصلح حيًا | نعم |
| get_my_role | لا | EXECUTE | — |
| trust_set_lesson_progress | لا | لا | EXECUTE |
