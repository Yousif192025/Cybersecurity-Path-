# File manifest — produced 2026-11-25

## New
- docs/supabase/README.md
- docs/supabase/CHANGE_REGISTER.md
- docs/supabase/FILE_MANIFEST.md
- docs/supabase/schema/TARGET_SCHEMA.md
- docs/supabase/roadmap/BATCH_ROADMAP.md
- docs/supabase/batch-1/** (sql + app-patches + ACCEPTANCE)
- docs/supabase/gate-c/** (copy of prior Gate C; C05/C06 marked superseded)

## Intentionally not modified
- docs/academy/labs/** (labs / simulation / fixed-data)
- docs/supabase/supabase.js (absent here; forbidden if present)
- Production Supabase project
- Git history / commit / push

## Absent from this workspace (apply patches on full repo)
- docs/assets/js/gatekeeper.js
- docs/assets/js/dashboards/router.js
- docs/academy/enrollment.html
