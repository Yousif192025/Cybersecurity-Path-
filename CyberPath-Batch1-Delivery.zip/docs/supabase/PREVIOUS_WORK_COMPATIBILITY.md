# PREVIOUS_WORK_COMPATIBILITY — Batch 1 delivery vs prior CyberPath work

## Context

This delivery was produced in an agent workspace that **does not** contain the full Codespaces tree at `/workspaces/Cybersecurity-Path-/`.  
Prior Gate A/B/C work, live Supabase fixes, and many academy JS files live primarily in Codespaces and were **not** fully mirrored here. This package is an **additive** merge candidate, not a replacement for `docs/supabase/` history.

## What this package adds (new)

| Path | Purpose |
|------|---------|
| `docs/supabase/batch-1/sql/00_preflight.sql` | Read-only preflight for B1 tables/roles |
| `docs/supabase/batch-1/sql/01_snapshot_b1.sql` | Snapshot policies/RLS/grants for B1 tables only |
| `docs/supabase/batch-1/sql/02_up_b1.sql` | Executable B1 migration (excludes user_profile B0) |
| `docs/supabase/batch-1/sql/03_validate_b1.sql` | Privilege/function gates after UP |
| `docs/supabase/batch-1/sql/04_rollback_b1.sql` | B1-only rollback; does not touch B0 profile |
| `docs/supabase/batch-1/app-patches/*` | Helper JS for get_my_role + progress/enroll RPCs |
| `docs/supabase/batch-1/ACCEPTANCE.md` | Acceptance states (repo / tested / ready / blocked) |
| `docs/supabase/schema/TARGET_SCHEMA.md` | Target schema roadmap (multi-batch) |
| `docs/supabase/roadmap/BATCH_ROADMAP.md` | B0–B6 ordering |
| `docs/supabase/CHANGE_REGISTER.md` | Classification of prior decisions |
| `docs/supabase/README.md` | Package entrypoint |
| `docs/supabase/FILE_MANIFEST.md` | Internal file list at packaging time |
| `docs/supabase/PREVIOUS_WORK_COMPATIBILITY.md` | This file |
| `docs/supabase/DELIVERY_MANIFEST.md` | Delivery manifest with hashes |

## What was modified relative to prior Gate C copy

| Path | Change |
|------|--------|
| `docs/supabase/gate-c/C05_UP.sql` | Replaced body with **superseded notice** pointing to `batch-1/sql/02_up_b1.sql` |
| `docs/supabase/gate-c/C06_DOWN.sql` | Replaced body with **superseded notice** pointing to `batch-1/sql/04_rollback_b1.sql` |

Other Gate C files (`C01`–`C04`, `C07`–`C10`, `BLOCKER.md`) were **copied as-of agent workspace** from `migration-packs/gate-c-readiness/` at packaging time. They may **differ** from newer edits you made only in Codespaces after that copy.

## What is marked superseded (do not apply on live DB)

- Original all-tables `C05_UP.sql` (would rewrite `user_profile` policies).
- Original `C06_DOWN.sql` that could restore unsafe pre-B0 profile grants.

## What this agent could not access

| Item | Impact |
|------|--------|
| Full Codespaces `docs/supabase/` history (Gate A/B reports, extra SQL, backups) | Not included; merge manually; do not delete Codespaces copies |
| `docs/assets/js/gatekeeper.js`, `router.js`, `student.js`, `admin.js` | Only **patch helpers** shipped; no in-place edit of missing originals |
| `docs/academy/enrollment.html` | Not present here |
| Live Supabase catalog after your permanent profile fix (beyond your descriptions) | B1 SQL designed to **exclude** `user_profile`; still run `00_preflight` on live |
| Your local cyberpath_test / Pack 1 run artifacts | Not re-run in this packaging session |

## Possible conflicts with live Supabase fixes

| Live fix (as reported) | Batch 1 interaction |
|------------------------|---------------------|
| `user_profile` restricted SELECT/UPDATE; no client `role` change | **B1 does not alter user_profile policies/grants** |
| `get_my_role()` DEFINER | **B1 does not drop/replace it**; validate checks it still exists |
| Frontend not yet deployed for RPC role | Deploy app-patches / your gatekeeper changes **with or before** relying on hidden `role` column |
| `enroll_student_in_path_courses` trigger drop in B1 UP | **Product decision**: stops auto-enroll on profile insert; confirm before apply |
| `enroll_self_in_course` INSERT column set | May fail if extra NOT NULL columns exist without defaults — catch in preflight/validate |
| Restoring old Gate C C05 on production | **Must not** — conflicts with B0 |

## Merge guidance for Codespaces

1. Keep all existing Gate A/B/C and backup files.
2. Copy this tree under `docs/supabase/` **alongside** existing files (or merge file-by-file).
3. If Codespaces already has richer `C01`–`C10`, prefer Codespaces versions except adopt the **supersede** stance for C05/C06 apply path.
4. Use `batch-1/sql/02_up_b1.sql` as the production candidate for B1, not archived C05.
