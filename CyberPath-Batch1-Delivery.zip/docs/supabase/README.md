# CyberPath — Supabase execution package

**Status:** B1 SQL ready for **owner-operated** apply. Not executed by the packaging agent.  
**Live baseline protected:** `user_profile` ACL + `get_my_role()` (B0).

## Layout

```
docs/supabase/
  README.md
  CHANGE_REGISTER.md
  schema/TARGET_SCHEMA.md
  roadmap/BATCH_ROADMAP.md
  gate-c/                 # archived/corrected Gate C notes; C05/C06 superseded
  batch-1/
    ACCEPTANCE.md
    sql/
      00_preflight.sql
      01_snapshot_b1.sql
      02_up_b1.sql        # <-- apply this, not gate-c/C05
      03_validate_b1.sql
      04_rollback_b1.sql
    app-patches/
      README.md
      get_my_role_helper.js
      progress_rpc_example.js
```

## Apply order (owner)

1. `00_preflight.sql`
2. `01_snapshot_b1.sql` (save outputs)
3. Written approval
4. `02_up_b1.sql`
5. `03_validate_b1.sql`
6. Merge app-patches into academy JS and deploy frontend

## Explicit non-actions in this package

- No live SQL from the agent
- No service_role secrets in files
- No auth.users / handle_student_linking changes
- No default privileges ALTER
- No payment/subscription tables created
