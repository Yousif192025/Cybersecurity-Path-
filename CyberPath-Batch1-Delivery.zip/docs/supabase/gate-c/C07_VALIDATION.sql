-- Gate C validation probes (run on cyberpath_test or post-apply Staging/Prod window)
-- Expectation notes in comments. Use separate sessions for SET ROLE where required.
-- NOT executed during Gate C packaging.

-- V1: anon cannot SELECT enrollments
SET ROLE anon;
SELECT 1 FROM public.enrollments LIMIT 1;  -- expect: permission denied / 0 with RLS
RESET ROLE;

-- V2: authenticated cannot INSERT learning_progress directly
SET ROLE authenticated;
INSERT INTO public.learning_progress DEFAULT VALUES;  -- expect: permission denied
RESET ROLE;

-- V3: authenticated cannot UPDATE user_profile.role (column privilege or RLS)
-- Replace :uid with a real uuid in a controlled session with JWT claim set
-- UPDATE public.user_profile SET role = 'admin' WHERE user_id = auth.uid();  -- expect deny

-- V4: authenticated SELECT only own enrollments (two-user fixture required)
-- SET request.jwt.claim.sub and role; compare row counts

-- V5: report_lesson_activity rejects 100
-- SELECT public.report_lesson_activity(:lesson, 100);  -- expect exception

-- V6: trust_set denied for authenticated
-- SELECT public.trust_set_lesson_progress(auth.uid(), :lesson, 100);  -- expect 42501

-- V7: service_role may EXECUTE trust_set (server context only; never browser)
-- SET ROLE service_role; SELECT has_function_privilege('service_role',
--   'public.trust_set_lesson_progress(uuid,uuid,numeric)', 'EXECUTE');  -- expect true

-- V8: anon/authenticated can SELECT courses and lessons (open catalog)
SET ROLE anon;
SELECT 1 FROM public.courses LIMIT 1;
SELECT 1 FROM public.lessons LIMIT 1;
RESET ROLE;

-- V9: has_table_privilege checks
SELECT has_table_privilege('anon','public.enrollments','SELECT');           -- expect f
SELECT has_table_privilege('authenticated','public.learning_progress','INSERT'); -- expect f
SELECT has_column_privilege('authenticated','public.user_profile','role','UPDATE'); -- expect f

-- V10: Lab progress domain not mixed (application-level): no learning_progress writes from lab runners
-- Document-only assertion for Phase 3: simulation/lab storage remains local.

-- V11: ensure_user_profile does not grant admin role (inspect returned row.role)
