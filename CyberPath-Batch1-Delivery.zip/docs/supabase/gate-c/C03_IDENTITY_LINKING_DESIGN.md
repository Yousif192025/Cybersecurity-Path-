# C03 — Identity Linking Design

Aligned with Architecture Baseline AD-01–AD-13 and Phase 3 scope (no payment).

## 1. Principles

1. **Identity ≠ login method ≠ subscription ≠ entitlements** (separate entities).  
2. **Never** prove ownership of a student/academic record by email match or `national_id` match alone.  
3. **Never** let the client set `role` / admin / instructor on `user_profile`.  
4. Guest progress is local and untrusted for certificates or entitlements (AD-13).  
5. Academic trainee path remains in the architecture even if full verification is deferred.

## 2. Paths

### 2.1 Independent learner (email)

1. Supabase Auth sign-up / sign-in (email).  
2. Optional `ensure_user_profile` creates or returns profile for `auth.uid()` **without** privileged role.  
3. Progress via `report_lesson_activity` only.  
4. No automatic link to institutional student rows.

### 2.2 Academic trainee (university id)

1. Auth account exists or is created.  
2. Binding requires a **server-side verification** step (one-time token, registrar API, or staff-approved claim) — **not** `UPDATE user_profile SET national_id = …` from the client.  
3. Until verification succeeds, user remains independent learner.  
4. `handle_student_linking` **must not** be the production binding mechanism as previously designed (unsafe). Treat as **BLOCKED for reuse** until redesigned.

### 2.3 External subscriber

Same Auth identity; entitlements added as separate records later (out of Phase 3 billing). No client-written entitlement flags.

## 3. Profile creation / linking (safe)

| Step | Rule |
|------|------|
| Create profile | Server or DEFINER function; `user_id = auth.uid()`; default non-admin role only |
| Link Auth → student row | Requires proof of control of that student record independent of PII match |
| Reject | Binding when target student already linked to another `user_id` |
| Reject | Client-supplied `role`, `user_id` on insert/update |

## 4. Account takeover controls

- Disable or replace any trigger that links on email/`national_id` equality alone.  
- Rate-limit claim attempts.  
- Audit log server-side binds (future).  
- Confirm-email is an operational setting (F7): enable after mail pipeline tested — not a substitute for academic proof.

## 5. Phase 3 deferrals (explicit)

- Full academic verification UX  
- Multi-tenant institutional LMS (AD-11 target, not Phase 3 build)  
- Subscription entitlements engine  

These remain designed, not implemented, in Gate C SQL.
