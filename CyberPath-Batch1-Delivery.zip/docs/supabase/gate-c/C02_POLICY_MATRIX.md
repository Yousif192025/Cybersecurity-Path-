# C02 — Policy Matrix (target state)

Legend: **Allow** · **Deny** · **N/A** · **RPC-only** (no direct table privilege; SECURITY DEFINER path)

Roles: `anon` · `authenticated` · `service_role` (backend only; never in browser)

## user_profile

| Operation | anon | authenticated (own row) | authenticated (other row) | service_role |
|-----------|------|-------------------------|---------------------------|--------------|
| SELECT | Deny | Allow `user_id = auth.uid()` | Deny | Allow (admin ops) |
| INSERT | Deny | Deny direct; **RPC/provision path only** | Deny | Allow controlled |
| UPDATE (non-role cols) | Deny | Allow own safe cols only **or RPC** | Deny | Allow |
| UPDATE (`role`, entitlements) | Deny | **Deny** | Deny | Allow |
| DELETE | Deny | Deny | Deny | Allow |

**Rationale:** F10 self-role escalation; unlinkable null `user_id` rows must not be world-readable.

## enrollments

| Operation | anon | authenticated (own) | authenticated (other) | service_role |
|-----------|------|---------------------|-----------------------|--------------|
| SELECT | Deny | Allow own | Deny | Allow |
| INSERT | Deny | Deny direct **or** controlled RPC that cannot set academic entitlement | Deny | Allow |
| UPDATE | Deny | Deny status/percentage forgery | Deny | Allow |
| DELETE | Deny | Deny | Deny | Allow |

**Rationale:** Remove USING true ALL; keep academic enrollment meaning separate from open-course follow (B-FOLLOW-SEP remains open if schema lacks type discriminator).

## learning_progress

| Operation | anon | authenticated (own) | authenticated (other) | service_role |
|-----------|------|---------------------|-----------------------|--------------|
| SELECT | Deny | Allow own | Deny | Allow |
| INSERT/UPDATE | Deny | **RPC-only** `report_lesson_activity` (self-reported &lt; 100) | Deny | `trust_set_lesson_progress` only |
| DELETE | Deny | Deny | Deny | Allow |

**Rationale:** AD-13; local/guest progress never proves completion; client must not set `user_id` or 100% trusted.

## courses / lessons

| Operation | anon | authenticated | service_role |
|-----------|------|---------------|--------------|
| SELECT | Allow (open catalog; B-COURSE-AVAIL risk accepted until publish flag proven) | Allow | Allow |
| INSERT/UPDATE/DELETE | Deny | Deny | Allow |

**Rationale:** Preserve public learning content; block client mutation.

## Functions (EXECUTE)

| Function | anon | authenticated | service_role |
|----------|------|---------------|--------------|
| `report_lesson_activity` | Deny | Allow | Allow |
| `ensure_user_profile` | Deny | Allow (read/ensure only; no role grant) | Allow |
| `trust_set_lesson_progress` | Deny | **Deny** | **Allow only** |
| `handle_student_linking` | Not modified by Pack 1 / Gate C SQL default | — | Review in C04; do not expose to clients |

## Notes

- Admin UI must not rely on elevated JWT `role` column on `user_profile`.  
- Lab progress stays client-local in Phase 3; no table grants for labs in this matrix.
