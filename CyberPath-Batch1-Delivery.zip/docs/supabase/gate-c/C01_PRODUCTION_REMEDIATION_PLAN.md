# C01 — Production Remediation Plan

**Project:** CyberPath · **Target:** Supabase `suvpaunulhqfoclepwoz`  
**Gate:** C — Production Remediation Readiness (design only)  
**Baseline:** Gate A F1–F11 open · Gate B CLOSED (repairs not applied to prod) · Pack 1 `065501-R2` local-only  
**Backup fingerprint (external):** `d1443d715c2d831c4bc3226dc66255e93db836ba226b19ab1824b9aa69b1700e`  
**Constraint:** Supabase Free · no new cloud project · no plan upgrade · no production execution in Gate C

## 1. Priority order and dependencies

| Step | Work package | Depends on | Why first |
|------|----------------|------------|-----------|
| S0 | Pre-flight: confirm backup restoreability, maintenance window, owner sign-off | — | Safety net |
| S1 | Snapshot Production catalog (policies, grants, triggers, functions) via read-only export **by owner/operator** | S0 | DOWN accuracy |
| S2 | P0 table grants + RLS on `user_profile`, `enrollments`, `learning_progress` | S1 | Stops cross-user read/write and role self-escalation paths documented in F1–F2, F10 |
| S3 | P0 `courses` / `lessons` grants + RLS (public SELECT kept) | S2 | Completes five-table surface without closing open catalog |
| S4 | Replace/restrict client write paths; deploy DEFINER RPCs (`report_lesson_activity`, `trust_set_*`, `ensure_user_profile` contract) | S2–S3 | Trusted vs self-reported progress (AD-13) |
| S5 | Isolate `enroll_student_in_path_courses` on `user_profile` if still auto-enrolling insecurely | S4 | Prevents side-effect enroll on profile create |
| S6 | Identity linking design application (no email/national_id alone) — **may be partially BLOCKED pending product rules** | S2, C03 | Account takeover prevention |
| S7 | Default privileges policy for **future** objects (report + limited ALTER if privileged role available) | S2 | F-residuals; may remain external_blocker under Free/postgres membership limits |
| S8 | Post-change validation matrix (C07) on Staging or controlled prod window | S2–S5 | Evidence before declaring remediation applied |

Pack 1 `065501-R2` is the **local reference** for S2–S5 style changes. Production apply requires C08 runbook + owner approval, not automatic reuse of local-only snapshots.

## 2. Per-item rationale and impact of not fixing

| Item | Evidence (Gate A / audits) | Impact if unfixed |
|------|----------------------------|-------------------|
| Broad grants + RLS off on most public tables | Catalog: 26/32 RLS disabled; anon/authenticated broad grants | Cross-tenant data exposure |
| `enrollments` permissive ALL / USING true | Policy audit | Any authenticated user can read/write all enrollments |
| `user_profile` self-UPDATE of `role` | Local exploit path; F10 production blocker | Privilege escalation to admin/instructor |
| Profile rows with `user_id IS NULL` readable | Overlapping SELECT policies | PII / student record leakage |
| Client-writable `learning_progress` | Grants + missing isolation | Forged completion / cross-user progress |
| `handle_student_linking` / email-national_id link | Design risk; out of Pack 1 scope | Account takeover if still live |
| Default privileges ALL to clients | Residuals report | New tables inherit unsafe grants |

## 3. Risk and outage probability (qualitative)

| Change | Outage / break risk | Mitigation |
|--------|---------------------|------------|
| REVOKE client INSERT/UPDATE on progress/profile | App features that wrote directly from browser break | Ensure RPC-only writes deployed in same window |
| RLS enable + own-row policies | Legitimate admin UIs using user JWT lose global SELECT | Route admin via service_role backend only |
| Drop enroll trigger | New profiles no longer auto-enroll paths | Intentional; product must call explicit enroll later |
| Identity linking changes | Registration flows fail | Feature-flag; do not ship until C03 accepted |

## 4. Explicit non-goals of Gate C package

- Execute SQL on Production  
- Close F1–F11 without post-apply evidence  
- Fix Default Privileges if session cannot ALTER them (document only)  
- Multi-tenant LMS (AD-11) implementation  
- Payment / subscriptions  
