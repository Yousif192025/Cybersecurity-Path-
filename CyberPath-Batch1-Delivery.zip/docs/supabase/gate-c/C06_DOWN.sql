-- SUPERSEDED. Production rollback for batch 1:
-- docs/supabase/batch-1/sql/04_rollback_b1.sql
-- Never restore pre-B0 user_profile grants/policies from old snapshots.
SELECT 'C06_DOWN.sql superseded by batch-1/sql/04_rollback_b1.sql' AS notice;
