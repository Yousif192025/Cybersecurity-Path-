# C09 — Risk Register (Gate C)

| ID | Risk | Severity | Impact | Treatment | Dependency |
|----|------|----------|--------|-----------|------------|
| R1 | Cross-user data via grants/RLS | Critical | Data breach | C05 grants+RLS | Owner apply |
| R2 | Self-role escalation (F10) | Critical | Admin takeover | Revoke column UPDATE; no client role write | C05 + app |
| R3 | Forged completion | High | False certificates/entitlements | trust_set service_role only; report &lt;100 | C05 + AD-13 |
| R4 | Account link by email/national_id | High | Account takeover | C03 redesign; don’t reuse handle_student_linking | Product + eng |
| R5 | App break after REVOKE direct writes | Medium | Feature outage | Ship RPC clients same window | Frontend |
| R6 | B-COURSE-AVAIL full catalog SELECT | Medium | Non-public rows visible if any | Publish flag when proven | Schema evidence |
| R7 | Default privileges residuals | Medium | Future tables unsafe | Policy for future; may stay open under Free | Privileged role |
| R8 | Incomplete DOWN without prod snapshot | High | Cannot clean-rollback | Mandatory pre-snapshot | Operator |
| R9 | Auth.uid / JWT mismatch (M1) | Medium | RPC failures | Validate PostgREST path | Staging test |
| R10 | B-TRACK profile provision | Medium | ensure_user_profile raises | Product decision on track/defaults | Owner |

**Cannot close before additional evidence:** R4 (live Auth trigger behavior), R7 (membership for default ACL roles), R6 (whether all course/lesson rows are public), F1–F11 formal closure after prod C07.
