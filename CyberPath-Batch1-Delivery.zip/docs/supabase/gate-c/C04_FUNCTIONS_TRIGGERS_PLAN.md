# C04 — Functions & Triggers Plan

Evidence basis: prior catalog audits, Pack 1 design, local restore tests. **Statuses are as last documented; re-confirm on Production catalog before apply.**

## Functions in scope

| Name | Prior status | Target | EXECUTE | search_path | Notes |
|------|--------------|--------|---------|-------------|-------|
| `ensure_user_profile` | May exist or be created by Pack 1 | SECURITY DEFINER; returns own profile; **no role elevation**; may raise if provision policy open (B-TRACK) | `authenticated`, `service_role` | `public, pg_temp` | No client INSERT on `user_profile` required |
| `report_lesson_activity(uuid, numeric)` | Pack 1 target | DEFINER; self-report &lt; 100; FLOOR to int; own `auth.uid()` only | `authenticated`, `service_role` | `public, pg_temp` | Not proof of completion |
| `trust_set_lesson_progress(uuid,uuid,numeric)` | Pack 1 target | DEFINER; trusted completion 0–100 whole | **`service_role` only** | `public, pg_temp` | Never browser |
| `handle_student_linking` | Present historically; unsafe link patterns | **Do not use for binding**; leave in place or disable only under separate approved change | Revoke from `anon`/`authenticated` if still granted | Review | **Out of Pack 1 apply path**; Gate C recommends isolation design, not silent drop on `auth.users` |
| `enroll_student_in_path_courses` | Trigger fn on profile insert | Keep function; **drop/disable trigger** on `user_profile` if it auto-enrolls without authorization | As today for fn | Review | Aligns Pack 1 R2 |

## Triggers

| Trigger / table | Prior | Target |
|-----------------|-------|--------|
| `enroll_student_in_path_courses` on `public.user_profile` | Enabled path risk | Isolated (DROP TRIGGER) in remediation aligned with Pack 1 |
| Triggers on `auth.users` (`on_auth_user_created`, linking) | Sensitive | **No change in Pack 1 / default Gate C UP**; requires privileged Auth-safe change + C03 |

## Privilege escalation paths to eliminate

1. Client UPDATE `user_profile.role`  
2. Client EXECUTE of any DEFINER that writes arbitrary `user_id` progress as trusted 100%  
3. Auto-link trigger on PII match  
4. Permissive RLS allowing SELECT/UPDATE of others’ rows  

## Dependencies

- Table RLS/grants (C02) before relying on RPC-only writes  
- App deploy must call RPCs instead of direct PostgREST writes  
- B-TRACK blocks automatic profile provision defaults until track constraint decided
