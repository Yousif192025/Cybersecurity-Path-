-- SUPERSEDED for production apply.
-- Do NOT run this file on Production.
-- Use instead: docs/supabase/batch-1/sql/02_up_b1.sql
-- Reason: this original C05 rewrote user_profile policies and conflicted with
-- permanent B0 remediation (column-limited SELECT/UPDATE + get_my_role).
-- Historical reference only.
SELECT 'C05_UP.sql superseded by batch-1/sql/02_up_b1.sql' AS notice;
