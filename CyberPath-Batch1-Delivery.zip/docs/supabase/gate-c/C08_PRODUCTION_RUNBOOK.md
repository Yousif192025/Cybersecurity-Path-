# C08 — Production Runbook (DO NOT EXECUTE IN GATE C)

## Roles

| Role | Responsibility |
|------|----------------|
| Project owner | Approve window, backup, go/no-go |
| Technical operator | psql apply, capture snapshots |
| Verifier | Run C07 probes, sign results |

## Preconditions

1. Backup fingerprint verified restorable: `d1443d715c2d831c4bc3226dc66255e93db836ba226b19ab1824b9aa69b1700e`  
2. Pack 1 `065501-R2` local cycle green (already claimed by project).  
3. Application build ready to use RPCs (no direct client writes to progress/profile).  
4. Maintenance window communicated.  
5. Written owner approval for Production change.  
6. Production catalog snapshot directory prepared (`gate_c_prod_snapshots/`) via **read-only** export by operator.

## Apply order (future)

1. Capture Production pre-state (policies, grants, triggers, functions) — same method as Pack 1 `00`.  
2. Apply `C05_UP.sql` via privileged `psql` session (not Dashboard paste for multi-statement transaction reliability).  
3. Run pack_scope subset of C07 immediately.  
4. Smoke app: login, open course list, attempt progress save via RPC.  
5. If fail → C06 with **pre** snapshots or backup restore; stop.

## Stop conditions

- Any pack_scope gate failure  
- App cannot read public courses/lessons  
- Mass 401/403 on legitimate own-row reads  
- Unexpected DDL error mid-transaction (confirm rollback)

## Rollback

1. Prefer transaction abort if still open.  
2. Else `C06_DOWN.sql` + pre snapshots from **this** window.  
3. Else restore backup after owner approval.  
4. **Do not** hand-recreate USING true ALL policies “to fix the app.”

## Out of runbook

Default privileges for non-owned roles; Auth trigger redesign; plan upgrade; new Supabase project.
