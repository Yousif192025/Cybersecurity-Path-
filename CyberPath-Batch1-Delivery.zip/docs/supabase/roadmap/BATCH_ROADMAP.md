# خارطة الدفعات

| دفعة | المحتوى | اعتمادية | حالة الحزمة |
|------|---------|----------|-------------|
| **B0** | حماية user_profile + get_my_role | — | **منفَّذ على الحي** — لا تكرار |
| **B1** | enrollments + learning_progress + courses/lessons ACL/RLS + RPCs تقدم | B0 | **SQL جاهز في المستودع** — يطبقه المالك |
| **B1-app** | نشر gatekeeper/router + إزالة كتابات مباشرة متعارضة | B0، يتزامن مع B1 | **رقع في المستودع** |
| **B2** | ensure/provision profile الآمن بدون track عشوائي؛ سياسات تحديث track عبر RPC | قرار B-TRACK | تصميم |
| **B3** | identity_proofs + audit_events؛ تعطيل مسارات ربط غير آمنة | قرار منتج | تصميم |
| **B4** | تقييمات/محاولات اختبار موثوقة | B1 | لاحق |
| **B5** | entitlements/subscriptions | تجاري | مؤجل |
| **B6** | default privileges للمستقبل | صلاحيات مالك الكائنات | مؤجل |

ترتيب تطبيق B1: Snapshot → Preflight → UP → Validate → (فشل → Rollback الدفعة فقط).
