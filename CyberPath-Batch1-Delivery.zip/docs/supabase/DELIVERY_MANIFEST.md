# DELIVERY_MANIFEST — CyberPath Batch 1

Package root: `docs/supabase/` (zipped as CyberPath-Batch1-Delivery.zip)

| Relative path | Kind | Tested here | SHA-256 | Summary |
|---------------|------|-------------|---------|---------|
| `CHANGE_REGISTER.md` | new | no | `929a59670b3e8ac9ddb534533abaa6c4ca16d067b95404dbca45d47fdd224a57` | # سجل التصحيحات والقرارات — CyberPath DB/App (2026-11-25) |
| `DELIVERY_MANIFEST.md` | new-delivery-meta | no | `a002bfc3e96180baac386dd87aff26cc21db60516517c153b88387a30f20cef1` | # DELIVERY_MANIFEST — CyberPath Batch 1  Package root: `docs/supabase/` (zippe |
| `FILE_MANIFEST.md` | new | no | `0c74a00f9d8bd4dd502e8e686005ee7c2b587baab0c16acb061ba74483123ce3` | # File manifest — produced 2026-11-25  ## New  |
| `PREVIOUS_WORK_COMPATIBILITY.md` | new-delivery-meta | no | `950dbfa411fdaf5ab50d592fa5e61274674ef40a12d4141b328749b96129ffe3` | # PREVIOUS_WORK_COMPATIBILITY — Batch 1 delivery vs prior CyberPath work  ## C |
| `README.md` | new | no | `e2d2b2c392714a2b067a0385d1b717c8f91faa8bd99d2aec2c73cb56cd5d52ce` | # CyberPath — Supabase execution package  **Status:** B1 SQL ready for **owner |
| `batch-1/ACCEPTANCE.md` | new | no | `87d058d784b0cdf3412853d02f402035e50df5651f18264707f21ce6763a242f` | # B1 Acceptance  ## تم تنفيذه داخل المستودع  |
| `batch-1/app-patches/README.md` | new | no | `533b3242b87217f5d8bf79cda92fb43a4a436715abaf387a54d8107e2366d957` | # رقع التطبيق — الدفعة B1  هذه البيئة لا تحتوي |
| `batch-1/app-patches/get_my_role_helper.js` | new | no | `f5b6b50bbee8274ef5c58b4f7d1bdc655cdb658bc533ef33bf5cef2aba187df5` | /**  * CyberPath — authoritative role helper (B0/B1)  * Do not read role from  |
| `batch-1/app-patches/progress_rpc_example.js` | new | no | `61d29929670f5704d0f288dad3c55f1ebf30f99ddfd844235f7975596030d36c` | /**  * Self-reported lesson progress (< 100). Not certificate proof.  */  |
| `batch-1/sql/00_preflight.sql` | new | no | `78d8e9dc8740b99636599917a2c4c9736f7698958529c30fe462475853b0c243` | -- B1 Preflight — run read-only before UP on the target DB -- Does not change  |
| `batch-1/sql/01_snapshot_b1.sql` | new | no | `c63ab847928b9edaccaa4fa3ecedfa26488896abf8c0cf81615a6fa8b2bd6460` | -- B1 Snapshot — capture policies/grants/triggers for enrollments, learning_pr |
| `batch-1/sql/02_up_b1.sql` | new | no | `fddeb64a64f62f826ad660d8dd83b2c28567f1886a71db711761129234334d98` | -- ============================================================================= |
| `batch-1/sql/03_validate_b1.sql` | new | no | `be1833e9bf9c3027ce20b42add775727af308bcbca80636bbfc2e89cd931ceba` | -- B1 validation — run after successful UP \set ON_ERROR_STOP on   |
| `batch-1/sql/04_rollback_b1.sql` | new | no | `2df6a489e53d8a421b41001dbafff6adb947d9adb8923a88066fbba12750a297` | -- B1 Rollback — removes B1 objects/policies and restores from operator snapsh |
| `gate-c/BLOCKER.md` | copied-from-agent-gate-c | no | `5e966e834701cd847a4da05f081c322939663b922769752ede2eff49838e20d1` | # BLOCKER log (Gate C)  Items that prevent claiming full production remediation  |
| `gate-c/C01_PRODUCTION_REMEDIATION_PLAN.md` | copied-from-agent-gate-c | no | `bf17ec64878cee040072a8ef0adeef3469b2be9234bee0dd078405a3e2f2612b` | # C01 — Production Remediation Plan  **Project:** CyberPath · **Target:** Sup |
| `gate-c/C02_POLICY_MATRIX.md` | copied-from-agent-gate-c | no | `36c94f442690152747e1cd36362b304c27e3a3461c48c5ed3bc0580719ee06af` | # C02 — Policy Matrix (target state)  Legend: **Allow** · **Deny** · **N/A** |
| `gate-c/C03_IDENTITY_LINKING_DESIGN.md` | copied-from-agent-gate-c | no | `f8ff311a75c5efd3a3971d9e16a0312f4eefce3f075b19fcb0942e5c08e2f0be` | # C03 — Identity Linking Design  Aligned with Architecture Baseline AD-01–AD |
| `gate-c/C04_FUNCTIONS_TRIGGERS_PLAN.md` | copied-from-agent-gate-c | no | `6b0ac9f0a8f7526fd9b1a6449caefe06010603337816c7040822816df15b2a65` | # C04 — Functions & Triggers Plan  Evidence basis: prior catalog audits, Pack  |
| `gate-c/C05_UP.sql` | modified-superseded | no | `34f58d91b0d5038d85842e52ff8f291fe3dd9a38a730975478f0c75aa7c01735` | -- SUPERSEDED for production apply. -- Do NOT run this file on Production. -- Us |
| `gate-c/C06_DOWN.sql` | modified-superseded | no | `27e86b05a67ccb1755dd7c117a9b924b5dea1e344e811580f8fcd068e615a8f3` | -- SUPERSEDED. Production rollback for batch 1: -- docs/supabase/batch-1/sql/04_ |
| `gate-c/C07_VALIDATION.sql` | copied-from-agent-gate-c | no | `0edc640f74a36d2b643f2e79ee7d9467f37f1db23617db9d3f4c2d332a6f2377` | -- Gate C validation probes (run on cyberpath_test or post-apply Staging/Prod wi |
| `gate-c/C08_PRODUCTION_RUNBOOK.md` | copied-from-agent-gate-c | no | `c6fc64983d326be1e7dcf147e4dc993be33aa37bfe95d1148128885338dd95f3` | # C08 — Production Runbook (DO NOT EXECUTE IN GATE C)  ## Roles  |
| `gate-c/C09_RISK_REGISTER.md` | copied-from-agent-gate-c | no | `29cf55c5a4904dae4f0754a6c4776033d37090f26a04a7de93e5cb8cf99790a7` | # C09 — Risk Register (Gate C)  \| ID \| Risk \| Severity \| Impact \| Treatme |
| `gate-c/C10_ACCEPTANCE_REPORT.md` | copied-from-agent-gate-c | no | `640cbe965a831e26c67b81825e62a89002666f1e83c0b9fa98fdb5c255f7c26a` | # C10 — Acceptance Report (Gate C packaging)  ## Deliverables  |
| `roadmap/BATCH_ROADMAP.md` | new | no | `6f7a29a762363c45aea6fc48724e3fc1e42b6081a9038c55d822257783fc80b3` | # خارطة الدفعات  \| دفعة \| المحتوى \| اعتمادية \ |
| `schema/TARGET_SCHEMA.md` | new | no | `19ba37a87b419400c46dc8d7f607691f27ff40fc798edb87d148d03dc92d7397` | # مخطط قاعدة البيانات المستهدف — CyberPath  **مبد� |
