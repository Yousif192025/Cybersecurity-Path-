# B1 Acceptance

## تم تنفيذه داخل المستودع
- SQL: preflight, snapshot, UP, validate, rollback
- مخطط مستهدف + خارطة دفعات + سجل تصحيح
- رقع تطبيق مقترحة تحت `app-patches/`

## تم اختباره محليًا
- **لم يُشغَّل** ضد Production أو cyberpath_test في هذه الجلسة.

## جاهز ليطبقه المالك على Supabase
1. تشغيل `00_preflight.sql` (قراءة).
2. تشغيل `01_snapshot_b1.sql` وحفظ المخرجات.
3. موافقة كتابية.
4. تشغيل `02_up_b1.sql`.
5. تشغيل `03_validate_b1.sql` — كل `pass = true`.
6. نشر رقع `gatekeeper` / استدعاءات التقدم إن وُجدت في فرعكم.

## يحتاج قرارًا قبل التنفيذ
- هل إسقاط trigger `enroll_student_in_path_courses` مقبول فورًا؟ (مضمّن في UP)
- هل أعمدة INSERT الافتراضية في `enrollments` تسمح بـ INSERT (user_id, course_id) فقط دون NOT NULL أخرى؟ **تحققوا في preflight من الأعمدة الإلزامية**؛ إن فشل `enroll_self_in_course` عدّلوا الدالة بعد كشف المخطط.

## لم يُنفذ
- أي SQL على المشروع الحي `suvpaunulhqfoclepwoz`
- commit / push / deploy
- B2+ جداول جديدة
