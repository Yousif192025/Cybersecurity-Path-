-- B1 Rollback — removes B1 objects/policies and restores from operator snapshot
-- WARNING: Restoring b1_pre_policies.sql may reintroduce unsafe USING(true) ALL.
-- Prefer: restore DB backup if snapshot is incomplete or known-unsafe.
-- Does NOT modify user_profile B0 remediation.

BEGIN;

DROP POLICY IF EXISTS enrollments_select_own ON public.enrollments;
DROP POLICY IF EXISTS learning_progress_select_own ON public.learning_progress;
DROP POLICY IF EXISTS courses_select_public ON public.courses;
DROP POLICY IF EXISTS lessons_select_public ON public.lessons;

DROP FUNCTION IF EXISTS public.report_lesson_activity(uuid, numeric);
DROP FUNCTION IF EXISTS public.trust_set_lesson_progress(uuid, uuid, numeric);
DROP FUNCTION IF EXISTS public.enroll_self_in_course(uuid);

REVOKE ALL ON TABLE public.enrollments FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.learning_progress FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.courses FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.lessons FROM PUBLIC, anon, authenticated;

-- Operator restores grants/policies/rls from snapshot taken by 01_snapshot_b1.sql:
-- \i b1_pre_rls.sql
-- \i b1_pre_policies.sql
-- \i b1_pre_grants_tables.sql
-- Optionally re-create enroll trigger from pre-B1 definition if required by product.

COMMIT;

-- get_my_role and user_profile B0 state intentionally untouched.
