-- B1 Snapshot — capture policies/grants/triggers for enrollments, learning_progress, courses, lessons
-- and function defs for progress RPCs if any. Does NOT snapshot user_profile (B0 protected).
-- Operator: set output path appropriately (psql \o) or copy result sets to gate_c_prod_snapshots/b1/

\set ON_ERROR_STOP on
\pset tuples_only on
\pset format unaligned

\o b1_pre_policies.sql
SELECT format(
  'CREATE POLICY %I ON public.%I AS %s FOR %s TO %s%s%s;',
  p.polname, c.relname,
  CASE WHEN p.polpermissive THEN 'PERMISSIVE' ELSE 'RESTRICTIVE' END,
  CASE p.polcmd WHEN 'r' THEN 'SELECT' WHEN 'a' THEN 'INSERT' WHEN 'w' THEN 'UPDATE'
    WHEN 'd' THEN 'DELETE' WHEN '*' THEN 'ALL' END,
  CASE WHEN p.polroles = '{}'::oid[] OR p.polroles IS NULL THEN 'PUBLIC'
    ELSE (SELECT string_agg(CASE WHEN u.oid = 0 THEN 'PUBLIC' ELSE quote_ident(r.rolname) END, ', ' ORDER BY ord)
      FROM unnest(p.polroles) WITH ORDINALITY AS u(oid, ord)
      LEFT JOIN pg_roles r ON r.oid = u.oid AND u.oid <> 0) END,
  CASE WHEN p.polqual IS NOT NULL THEN ' USING (' || pg_get_expr(p.polqual, p.polrelid) || ')' ELSE '' END,
  CASE WHEN p.polwithcheck IS NOT NULL THEN ' WITH CHECK (' || pg_get_expr(p.polwithcheck, p.polrelid) || ')' ELSE '' END
)
FROM pg_policy p
JOIN pg_class c ON c.oid = p.polrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('enrollments','learning_progress','courses','lessons')
ORDER BY c.relname, p.polname;
\o

\o b1_pre_rls.sql
SELECT format('ALTER TABLE public.%I %s ROW LEVEL SECURITY;', c.relname,
  CASE WHEN c.relrowsecurity THEN 'ENABLE' ELSE 'DISABLE' END)
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public' AND c.relkind = 'r'
  AND c.relname IN ('enrollments','learning_progress','courses','lessons');
\o

\o b1_pre_grants_tables.sql
SELECT format('GRANT %s ON TABLE public.%I TO %s%s;', a.privilege_type, c.relname,
  CASE WHEN a.grantee = 0 THEN 'PUBLIC' ELSE quote_ident(r.rolname) END,
  CASE WHEN a.is_grantable THEN ' WITH GRANT OPTION' ELSE '' END)
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
CROSS JOIN LATERAL aclexplode(COALESCE(c.relacl, acldefault('r', c.relowner))) a
LEFT JOIN pg_roles r ON r.oid = a.grantee AND a.grantee <> 0
WHERE n.nspname = 'public' AND c.relkind = 'r'
  AND c.relname IN ('enrollments','learning_progress','courses','lessons')
ORDER BY c.relname, a.grantee, a.privilege_type;
\o

\pset tuples_only off
\pset format aligned
SELECT 'B1 snapshot files written (b1_pre_*.sql)' AS status;
