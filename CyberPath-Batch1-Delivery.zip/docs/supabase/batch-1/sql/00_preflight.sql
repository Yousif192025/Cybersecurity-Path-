-- B1 Preflight — run read-only before UP on the target DB
-- Does not change data. Operator runs on Supabase SQL editor or psql.

\set ON_ERROR_STOP on

-- Required roles
SELECT rolname FROM pg_roles
WHERE rolname IN ('anon','authenticated','service_role','postgres')
ORDER BY 1;

-- Five tables exist
SELECT c.relname, c.relrowsecurity, c.relforcerowsecurity
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('user_profile','enrollments','learning_progress','courses','lessons')
ORDER BY 1;

-- get_my_role must already exist (B0)
SELECT p.proname, p.prosecdef,
       pg_get_function_identity_arguments(p.oid) AS args,
       r.rolname AS owner
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
JOIN pg_roles r ON r.oid = p.proowner
WHERE n.nspname = 'public' AND p.proname = 'get_my_role';

-- Current policies on B1 tables (enrollments, learning_progress, courses, lessons)
SELECT tablename, policyname, roles, cmd, qual, with_check
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('enrollments','learning_progress','courses','lessons')
ORDER BY tablename, policyname;

-- Table privileges summary
SELECT grantee, table_name, privilege_type
FROM information_schema.role_table_grants
WHERE table_schema = 'public'
  AND table_name IN ('enrollments','learning_progress','courses','lessons')
  AND grantee IN ('anon','authenticated','PUBLIC')
ORDER BY table_name, grantee, privilege_type;
