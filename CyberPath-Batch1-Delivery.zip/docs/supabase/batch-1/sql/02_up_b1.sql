-- =============================================================================
-- B1 UP — Production remediation batch 1
-- Scope: enrollments, learning_progress, courses, lessons + progress RPCs
-- EXCLUDED: user_profile policies/grants (B0 permanent), auth.users, default privileges
-- EXCLUDED: handle_student_linking, academic auto-link
-- Do NOT run until: preflight OK + snapshot taken + owner approval
-- =============================================================================

BEGIN;

-- ----- 1) Drop policies only on B1 tables (not user_profile) -----
DO $$
DECLARE pol record;
BEGIN
  FOR pol IN
    SELECT policyname, tablename
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN ('enrollments','learning_progress','courses','lessons')
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', pol.policyname, pol.tablename);
  END LOOP;
END $$;

-- ----- 2) Enable RLS -----
ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;

-- ----- 3) Policies -----
CREATE POLICY enrollments_select_own ON public.enrollments
  FOR SELECT TO authenticated
  USING (user_id = (SELECT auth.uid()));

CREATE POLICY learning_progress_select_own ON public.learning_progress
  FOR SELECT TO authenticated
  USING (user_id = (SELECT auth.uid()));

CREATE POLICY courses_select_public ON public.courses
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE POLICY lessons_select_public ON public.lessons
  FOR SELECT TO anon, authenticated
  USING (true);

-- No INSERT/UPDATE/DELETE policies for authenticated/anon on these tables.
-- Writes go through SECURITY DEFINER RPCs or service_role.

-- ----- 4) Table ACL: strip client broad rights, re-grant SELECT only -----
REVOKE ALL ON TABLE public.enrollments FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.learning_progress FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.courses FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.lessons FROM PUBLIC, anon, authenticated;

GRANT SELECT ON TABLE public.enrollments TO authenticated;
GRANT SELECT ON TABLE public.learning_progress TO authenticated;
GRANT SELECT ON TABLE public.courses TO anon, authenticated;
GRANT SELECT ON TABLE public.lessons TO anon, authenticated;

-- Column-level INSERT/UPDATE leftovers for clients
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT table_name, column_name, grantee, privilege_type
    FROM information_schema.column_privileges
    WHERE table_schema = 'public'
      AND table_name IN ('enrollments','learning_progress','courses','lessons')
      AND grantee IN ('anon','authenticated')
      AND privilege_type IN ('INSERT','UPDATE','DELETE')
  LOOP
    EXECUTE format('REVOKE %s (%I) ON TABLE public.%I FROM %I',
      r.privilege_type, r.column_name, r.table_name, r.grantee);
  END LOOP;
  FOR r IN
    SELECT table_name, column_name, privilege_type
    FROM information_schema.column_privileges
    WHERE table_schema = 'public'
      AND table_name IN ('enrollments','learning_progress','courses','lessons')
      AND grantee = 'PUBLIC'
      AND privilege_type IN ('INSERT','UPDATE','DELETE')
  LOOP
    EXECUTE format('REVOKE %s (%I) ON TABLE public.%I FROM PUBLIC',
      r.privilege_type, r.column_name, r.table_name);
  END LOOP;
END $$;

-- ----- 5) Isolate auto-enroll trigger on user_profile (function kept) -----
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT t.tgname
    FROM pg_trigger t
    JOIN pg_class c ON c.oid = t.tgrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    JOIN pg_proc p ON p.oid = t.tgfoid
    WHERE NOT t.tgisinternal
      AND n.nspname = 'public'
      AND c.relname = 'user_profile'
      AND p.proname = 'enroll_student_in_path_courses'
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS %I ON public.user_profile', r.tgname);
  END LOOP;
END $$;

-- ----- 6) Progress RPCs -----
CREATE OR REPLACE FUNCTION public.report_lesson_activity(
  p_lesson_id uuid,
  p_self_reported_percentage numeric
)
RETURNS public.learning_progress
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  uid uuid := auth.uid();
  v_course uuid;
  pct integer;
  rec public.learning_progress;
  lock_key bigint;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'not authenticated';
  END IF;
  IF p_lesson_id IS NULL THEN
    RAISE EXCEPTION 'lesson_id required';
  END IF;
  IF p_self_reported_percentage IS NULL
     OR p_self_reported_percentage < 0
     OR p_self_reported_percentage >= 100 THEN
    RAISE EXCEPTION 'self-reported percentage must be in [0, 100)';
  END IF;
  pct := FLOOR(p_self_reported_percentage)::integer;

  SELECT l.course_id INTO v_course
  FROM public.lessons l
  WHERE l.lesson_id = p_lesson_id;
  IF v_course IS NULL THEN
    RAISE EXCEPTION 'invalid lesson';
  END IF;

  lock_key := hashtextextended(uid::text || ':' || p_lesson_id::text, 0);
  PERFORM pg_advisory_xact_lock(lock_key);

  SELECT * INTO rec
  FROM public.learning_progress
  WHERE user_id = uid AND lesson_id = p_lesson_id
  ORDER BY progress_id
  FOR UPDATE
  LIMIT 1;

  IF FOUND THEN
    UPDATE public.learning_progress SET
      course_id = v_course,
      completion_percentage = GREATEST(COALESCE(completion_percentage, 0), pct),
      last_accessed = now()
    WHERE progress_id = rec.progress_id
    RETURNING * INTO rec;
    RETURN rec;
  END IF;

  INSERT INTO public.learning_progress (
    user_id, course_id, lesson_id, completion_percentage, last_accessed
  ) VALUES (
    uid, v_course, p_lesson_id, pct, now()
  )
  RETURNING * INTO rec;
  RETURN rec;
END;
$$;

CREATE OR REPLACE FUNCTION public.trust_set_lesson_progress(
  p_user_id uuid,
  p_lesson_id uuid,
  p_completion_percentage numeric
)
RETURNS public.learning_progress
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_course uuid;
  pct integer;
  rec public.learning_progress;
  lock_key bigint;
BEGIN
  IF p_user_id IS NULL OR p_lesson_id IS NULL THEN
    RAISE EXCEPTION 'user_id and lesson_id required';
  END IF;
  IF p_completion_percentage IS NULL THEN
    RAISE EXCEPTION 'completion_percentage must not be null';
  END IF;
  IF p_completion_percentage < 0 OR p_completion_percentage > 100 THEN
    RAISE EXCEPTION 'completion_percentage must be in [0, 100]';
  END IF;
  IF p_completion_percentage <> trunc(p_completion_percentage) THEN
    RAISE EXCEPTION 'completion_percentage must be a whole number';
  END IF;
  pct := p_completion_percentage::integer;

  IF NOT EXISTS (
    SELECT 1 FROM public.user_profile up WHERE up.user_id = p_user_id
  ) THEN
    RAISE EXCEPTION 'target user profile not found';
  END IF;

  SELECT l.course_id INTO v_course
  FROM public.lessons l
  WHERE l.lesson_id = p_lesson_id;
  IF v_course IS NULL THEN
    RAISE EXCEPTION 'target lesson not found';
  END IF;

  lock_key := hashtextextended(p_user_id::text || ':' || p_lesson_id::text, 0);
  PERFORM pg_advisory_xact_lock(lock_key);

  SELECT * INTO rec
  FROM public.learning_progress
  WHERE user_id = p_user_id AND lesson_id = p_lesson_id
  ORDER BY progress_id
  FOR UPDATE
  LIMIT 1;

  IF FOUND THEN
    UPDATE public.learning_progress SET
      course_id = v_course,
      completion_percentage = pct,
      last_accessed = now()
    WHERE progress_id = rec.progress_id
    RETURNING * INTO rec;
    RETURN rec;
  END IF;

  INSERT INTO public.learning_progress (
    user_id, course_id, lesson_id, completion_percentage, last_accessed
  ) VALUES (
    p_user_id, v_course, p_lesson_id, pct, now()
  )
  RETURNING * INTO rec;
  RETURN rec;
END;
$$;

-- Optional: self-enroll in open course without academic entitlement semantics
CREATE OR REPLACE FUNCTION public.enroll_self_in_course(p_course_id uuid)
RETURNS public.enrollments
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  uid uuid := auth.uid();
  rec public.enrollments;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'not authenticated';
  END IF;
  IF p_course_id IS NULL THEN
    RAISE EXCEPTION 'course_id required';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.courses c WHERE c.course_id = p_course_id) THEN
    RAISE EXCEPTION 'course not found';
  END IF;

  SELECT * INTO rec
  FROM public.enrollments e
  WHERE e.user_id = uid AND e.course_id = p_course_id
  LIMIT 1;
  IF FOUND THEN
    RETURN rec;
  END IF;

  INSERT INTO public.enrollments (user_id, course_id)
  VALUES (uid, p_course_id)
  RETURNING * INTO rec;
  RETURN rec;
END;
$$;

REVOKE ALL ON FUNCTION public.report_lesson_activity(uuid, numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.report_lesson_activity(uuid, numeric) TO authenticated;

REVOKE ALL ON FUNCTION public.enroll_self_in_course(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.enroll_self_in_course(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.trust_set_lesson_progress(uuid, uuid, numeric) FROM PUBLIC, anon, authenticated;
-- Explicit client deny; grant service_role only
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN
    RAISE EXCEPTION 'service_role missing';
  END IF;
  EXECUTE 'GRANT EXECUTE ON FUNCTION public.trust_set_lesson_progress(uuid, uuid, numeric) TO service_role';
END $$;

-- ----- 7) Inline gates (fail → full ROLLBACK) -----
DO $$
BEGIN
  IF has_table_privilege('anon', 'public.enrollments', 'SELECT') THEN
    RAISE EXCEPTION 'B1 gate fail: anon can SELECT enrollments';
  END IF;
  IF has_table_privilege('authenticated', 'public.learning_progress', 'INSERT') THEN
    RAISE EXCEPTION 'B1 gate fail: authenticated can INSERT learning_progress';
  END IF;
  IF has_table_privilege('authenticated', 'public.learning_progress', 'UPDATE') THEN
    RAISE EXCEPTION 'B1 gate fail: authenticated can UPDATE learning_progress';
  END IF;
  IF NOT has_table_privilege('anon', 'public.courses', 'SELECT') THEN
    RAISE EXCEPTION 'B1 gate fail: anon cannot SELECT courses';
  END IF;
  IF has_function_privilege('authenticated', 'public.trust_set_lesson_progress(uuid,uuid,numeric)', 'EXECUTE') THEN
    RAISE EXCEPTION 'B1 gate fail: authenticated can EXECUTE trust_set';
  END IF;
  IF NOT has_function_privilege('authenticated', 'public.report_lesson_activity(uuid,numeric)', 'EXECUTE') THEN
    RAISE EXCEPTION 'B1 gate fail: authenticated missing report_lesson_activity';
  END IF;
END $$;

COMMIT;
