-- B1 validation — run after successful UP
\set ON_ERROR_STOP on

SELECT 'priv_anon_enrollments_select' AS test,
  NOT has_table_privilege('anon','public.enrollments','SELECT') AS pass;

SELECT 'priv_auth_progress_insert' AS test,
  NOT has_table_privilege('authenticated','public.learning_progress','INSERT') AS pass;

SELECT 'priv_auth_progress_update' AS test,
  NOT has_table_privilege('authenticated','public.learning_progress','UPDATE') AS pass;

SELECT 'priv_anon_courses_select' AS test,
  has_table_privilege('anon','public.courses','SELECT') AS pass;

SELECT 'priv_anon_lessons_select' AS test,
  has_table_privilege('anon','public.lessons','SELECT') AS pass;

SELECT 'fn_report_auth_exec' AS test,
  has_function_privilege('authenticated','public.report_lesson_activity(uuid,numeric)','EXECUTE') AS pass;

SELECT 'fn_trust_auth_no_exec' AS test,
  NOT has_function_privilege('authenticated','public.trust_set_lesson_progress(uuid,uuid,numeric)','EXECUTE') AS pass;

SELECT 'fn_trust_service_exec' AS test,
  has_function_privilege('service_role','public.trust_set_lesson_progress(uuid,uuid,numeric)','EXECUTE') AS pass;

SELECT 'fn_get_my_role_still_present' AS test,
  EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.proname = 'get_my_role' AND p.prosecdef
  ) AS pass;

SELECT 'rls_enabled_b1_tables' AS test,
  (SELECT count(*) FROM pg_class c
   JOIN pg_namespace n ON n.oid = c.relnamespace
   WHERE n.nspname = 'public'
     AND c.relname IN ('enrollments','learning_progress','courses','lessons')
     AND c.relrowsecurity) = 4 AS pass;

-- Policies present
SELECT 'policies_count' AS test, count(*) AS n
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('enrollments','learning_progress','courses','lessons');
