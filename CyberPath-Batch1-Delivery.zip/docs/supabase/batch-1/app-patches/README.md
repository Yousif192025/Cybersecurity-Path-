# رقع التطبيق — الدفعة B1

هذه البيئة لا تحتوي على `docs/assets/js/gatekeeper.js` الأصلي.
ضعوا الملفات التالية في مسارات المشروع الحقيقي عند الدمج.

## 1) role via RPC only

استبدلوا أي:
```js
// ANTI-PATTERN
const role = session.user?.user_metadata?.role
// or select('role').from('user_profile')
```
بـ:
```js
const { data: role, error } = await supabase.rpc('get_my_role')
```

## 2) progress write

```js
// ANTI-PATTERN
await supabase.from('learning_progress').upsert({ ... })

// REQUIRED after B1
await supabase.rpc('report_lesson_activity', {
  p_lesson_id: lessonId,
  p_self_reported_percentage: pct // must be < 100
})
```

## 3) enroll

```js
await supabase.rpc('enroll_self_in_course', { p_course_id: courseId })
```

## 4) admin reads of all enrollments

لا تُمنح من المتصفح. استخدموا Edge Function / backend بـ `service_role` بعد التحقق من `get_my_role() === 'admin'` على الخادم.

ملفات مرجعية للدمج اليدوي:
- `get_my_role_helper.js` — دالة مساعدة
- `progress_rpc_example.js` — مثال استدعاء
