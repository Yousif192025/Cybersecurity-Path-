\set ON_ERROR_STOP on
BEGIN;
DROP POLICY IF EXISTS user_profile_select_own ON public.user_profile;
DROP POLICY IF EXISTS enrollments_select_own ON public.enrollments;
DROP POLICY IF EXISTS learning_progress_select_own ON public.learning_progress;
DROP POLICY IF EXISTS courses_select_public ON public.courses;
DROP POLICY IF EXISTS lessons_select_public ON public.lessons;
DROP FUNCTION IF EXISTS public.report_lesson_activity(uuid, numeric);
DROP FUNCTION IF EXISTS public.trust_set_lesson_progress(uuid, uuid, numeric);
DROP FUNCTION IF EXISTS public.ensure_user_profile();
\i pack1_snapshots/pre_function_defs.sql
\i pack1_snapshots/pre_grants_functions.sql
\i pack1_snapshots/pre_triggers.sql
\i pack1_snapshots/pre_rls_state.sql
\i pack1_snapshots/pre_policies.sql
\i pack1_snapshots/pre_grants_tables.sql
\i pack1_snapshots/pre_grants_columns.sql
\i pack1_snapshots/pre_default_privileges.sql
COMMIT;
